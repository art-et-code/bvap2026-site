Photos de la galerie de campagne
