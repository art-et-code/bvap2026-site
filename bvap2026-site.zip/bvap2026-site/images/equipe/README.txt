Photos des colistiers (format carré recommandé)
