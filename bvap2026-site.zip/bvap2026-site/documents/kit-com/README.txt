Kit de communication (logos, visuels, etc.)
