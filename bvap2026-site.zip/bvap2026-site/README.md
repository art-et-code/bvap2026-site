# Bien Vivre à Perros 2026 🌊

Site web officiel de la campagne municipale "Bien Vivre à Perros" pour les élections de mars 2026 à Perros-Guirec (Côtes-d'Armor, Bretagne).

## 📁 Structure du projet

```
bvap2026-site/
├── index.html          # Page d'accueil
├── programme.html      # Notre programme (6 thématiques)
├── equipe.html         # Présentation de l'équipe
├── actualites.html     # Actualités et agenda
├── contact.html        # Contact, don et FAQ
├── presse.html         # Espace presse et kit com
├── css/
│   └── style.css       # Feuille de style principale
├── js/
│   └── main.js         # JavaScript (menu, animations, FAQ)
├── images/
│   └── favicon.svg     # Favicon du site
└── assets/             # Ressources additionnelles (PDF, etc.)
```

## 🚀 Déploiement sur GitHub Pages

1. Créer un repository sur GitHub
2. Pousser ce code sur la branche `main`
3. Aller dans Settings > Pages
4. Sélectionner "Deploy from a branch" > `main` > `/ (root)`
5. Le site sera accessible à `https://[votre-username].github.io/[nom-repo]/`

## ✏️ Personnalisation

### Éléments à compléter :

- **Photos** : Remplacer les placeholders par les vraies photos de l'équipe
- **Coordonnées** : Adresse du local, téléphone, emails
- **Réseaux sociaux** : Liens Facebook et Instagram
- **Dates** : Compléter l'agenda des événements
- **Documents** : Ajouter les PDF dans le dossier `assets/`

### Couleurs (CSS variables) :

```css
--bleu-ocean: #1a5f7a;      /* Couleur principale */
--bleu-profond: #0d3b4c;    /* Headers, footer */
--turquoise: #2d9596;       /* Accents, boutons */
--sable: #f5e6d3;           /* Arrière-plans alternés */
```

## 📱 Responsive

Le site est entièrement responsive et s'adapte aux écrans :
- Desktop (> 900px)
- Tablette (600-900px)
- Mobile (< 600px)

## 🔧 Technologies

- HTML5 sémantique
- CSS3 (Flexbox, Grid, Variables CSS, Animations)
- JavaScript vanilla (ES6+)
- Google Fonts (Playfair Display, Source Sans 3)

## 📄 Licence

© 2025 Bien Vivre à Perros 2026 - Tous droits réservés

---

*Ensemble, construisons l'avenir de Perros-Guirec !*
